insert into TODO
values(10001, 'Learn Automation Testing', false, sysdate() + 365, 'in28minutes');
insert into TODO
values(10002, 'Become a Tech Guru', false, sysdate() + 366, 'in28minutes');
insert into TODO
values(10003, 'Learn to Dance', false, sysdate() + 367, 'in28minutes');

insert into TODO
values(10004, 'Make Great Courses', false, sysdate() - 2, 'ranga');
insert into TODO
values(10005, 'Reach 1 Million Learners', false, sysdate() - 3, 'ranga');